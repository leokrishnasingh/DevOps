#!/bin/bash

echo "Enter your skills:"
read SKILL

echo "Your $SKILL skill is in high Demand in the IT Industry."

read -p 'Username: ' USR
read -sp 'Password: ' pass

echo

echo "Login Successfull: Welcome USER $USR,"
