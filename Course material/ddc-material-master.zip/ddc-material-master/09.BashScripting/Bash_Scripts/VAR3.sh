#!/bin/bash

echo "Value of NAME variable is $NAME"
echo "Value of Variable ELECTRIC is $ELECTRIC"
